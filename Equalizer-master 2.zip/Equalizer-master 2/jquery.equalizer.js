(function ($) {

    "use strict";

    $.fn.equalizer = function (options) {
        //plugin optons
        var settings = $.extend({
            columns: 3,
            container: ".container"
        }, options);
        
        var currentTallest = 0,
            rowDivs = [],
            eq = 0,
            currentDiv = 0;

        //height settings to be called in the return each function
        function heightAjust() {
            //allow height to adjust when resizing columns
            eq.height('auto');
            currentTallest = (currentTallest < eq.height()) ? (eq.height()) : (currentTallest);
            rowDivs.push(eq);
            for (currentDiv = 0; currentDiv < rowDivs.length; currentDiv++) {
                rowDivs[currentDiv].height(currentTallest);
            }
        }

        //return the functions for each item/column
        return this.each(function () {
            eq = $(this);
        
            heightAjust();
        });
    };
}(jQuery));